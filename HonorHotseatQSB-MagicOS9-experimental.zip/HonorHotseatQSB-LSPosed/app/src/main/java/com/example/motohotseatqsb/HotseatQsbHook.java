package com.example.motohotseatqsb;

import de.robv.android.xposed.IXposedHookInitPackageResources;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_InitPackageResources;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

/**
 * Experimental resource-override module for Honor MagicOS launchers.
 * The original Moto resource names are not confirmed to exist on Honor; each
 * override is attempted independently and failures are logged without crashing.
 */
public final class HotseatQsbHook implements IXposedHookInitPackageResources, IXposedHookLoadPackage {
    private static final String TAG = "HonorHotseatQSB";
    private static final String[] TARGETS = {
        "com.hihonor.android.launcher",
        "com.huawei.android.launcher"
    };
    // Candidate names only: actual names must be verified against the target ROM.
    private static final String[] BOOL_RESOURCES = {
        "config_enable_hotseat_qsb",
        "config_hotseat_qsb_default_value",
        "config_show_hotseat_qsb",
        "config_enable_qsb_on_hotseat",
        "config_show_google_search_bar"
    };

    private static boolean isTarget(String packageName) {
        for (String target : TARGETS) if (target.equals(packageName)) return true;
        return false;
    }

    @Override
    public void handleInitPackageResources(XC_InitPackageResources.InitPackageResourcesParam resparam) {
        if (!isTarget(resparam.packageName)) return;
        XposedBridge.log(TAG + ": resource hook entered for " + resparam.packageName);
        for (String resource : BOOL_RESOURCES) {
            try {
                resparam.res.setReplacement(resparam.packageName, "bool", resource, true);
                XposedBridge.log(TAG + ": requested bool/" + resource + "=true");
            } catch (Throwable t) {
                XposedBridge.log(TAG + ": bool/" + resource + " unavailable: " + t.getClass().getSimpleName());
            }
        }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (isTarget(lpparam.packageName)) {
            XposedBridge.log(TAG + ": loaded into launcher process " + lpparam.packageName);
        }
    }
}
