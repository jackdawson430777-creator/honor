# Honor Hotseat Google Search Bar — LSPosed（实验适配版）

面向 Honor MagicOS 桌面的实验性资源 Hook 模块。目标包名同时覆盖：

- `com.hihonor.android.launcher`（部分荣耀桌面版本）
- `com.huawei.android.launcher`（部分旧版/华为系桌面包名）

模块尝试把以下候选 bool 资源替换为 `true`：
`config_enable_hotseat_qsb`、`config_hotseat_qsb_default_value`、`config_show_hotseat_qsb`、`config_enable_qsb_on_hotseat`、`config_show_google_search_bar`。

**重要限制：** 这些资源名来自原 Motorola 模块或候选命名，尚未通过 MagicOS 9.0 实机或对应荣耀桌面 APK 确认。资源替换不等于创建 Google 搜索栏；如果荣耀桌面没有对应控件/布局，搜索栏不会凭空出现。此版本不应宣称已实测成功。

## 构建
使用 JDK 17、Android SDK 35，在项目目录运行 `gradle assembleDebug --no-daemon`，或使用 GitHub Actions 手动触发构建。

## 安装测试
1. 构建并安装 APK。
2. 在 LSPosed 启用模块，只勾选实际存在的荣耀桌面包名作用域。
3. 强行停止桌面后重新进入。若无变化，查看 LSPosed 日志中 `HonorHotseatQSB`。
4. 若日志显示候选资源不可用，需要提供 MagicOS 9.0 对应的荣耀桌面 APK（或资源表/反编译资源），才能确定真实资源名和布局实现。
